# Portfolio Dashboard

## About this example

A shiny application makes it easy to transform your analysis into an interactive dashboard using R so users can ask and answer questions in real-time, without having to touch any code.


## Learn more

* [Shiny Documentation](https://shiny.posit.co/)
* [Gallery of example Shiny apps](https://shiny.posit.co/r/gallery/)
* [Articles on Shiny](https://shiny.posit.co/r/articles/)

## Requirements

* R version 3.4 or higher

<!-- NOTE: this file is generated -->
